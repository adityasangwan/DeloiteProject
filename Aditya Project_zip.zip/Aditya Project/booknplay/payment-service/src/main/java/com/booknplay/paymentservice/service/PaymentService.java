package com.booknplay.paymentservice.service;

import com.booknplay.paymentservice.dto.PaymentRequest;
import com.booknplay.paymentservice.dto.PaymentResponse;
import com.booknplay.paymentservice.entity.Payment;
import com.booknplay.paymentservice.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;

    public PaymentResponse processPayment(PaymentRequest request) {
        String transactionId = UUID.randomUUID().toString();

        Payment payment = Payment.builder()
                .bookingId(request.getBookingId())
                .amount(request.getAmount())
                .status("SUCCESS") // Always succeed for now
                .transactionId(transactionId)
                .build();

        paymentRepository.save(payment);

        return new PaymentResponse(payment.getId(), payment.getStatus(), transactionId);
    }
}
