# BooknPlay - Microservices Demo

Contains full service code and structure.