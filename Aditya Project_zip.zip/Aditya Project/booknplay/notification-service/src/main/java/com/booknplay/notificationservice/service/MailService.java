package com.booknplay.notificationservice.service;

import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MailService {

    private final JavaMailSender mailSender;

    public void sendBookingConfirmation(String toEmail, String turfName, String timeSlot) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Booking Confirmed: " + turfName);
        message.setText("Your booking for " + turfName + " at " + timeSlot + " has been confirmed.");
        mailSender.send(message);
    }
}
