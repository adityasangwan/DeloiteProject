package com.booknplay.notificationservice.controller;

import com.booknplay.notificationservice.service.MailService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notify")
@RequiredArgsConstructor
public class NotificationController {

    private final MailService mailService;

    @PostMapping("/booking")
    public ResponseEntity<String> sendBookingEmail(
            @RequestParam String email,
            @RequestParam String turf,
            @RequestParam String slot
    ) {
        mailService.sendBookingConfirmation(email, turf, slot);
        return ResponseEntity.ok("Email sent successfully");
    }
}
//samplecall
//POST /notify/booking
//?email=user@gmail.com
//&turf=Urban Sports Center
//&slot=2025-07-01 17:00 - 18:00
