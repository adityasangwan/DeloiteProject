package com.booknplay.bookingservice.dto;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {
    private Long turfId;
    private Long userId;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
}
