package com.booknplay.bookingservice.repository;

import com.booknplay.bookingservice.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUserId(Long userId);

    List<Booking> findByTurfIdAndDateAndStartTimeLessThanAndEndTimeGreaterThan(
            Long turfId, LocalDate date, LocalTime end, LocalTime start
    );

    @Query(value = "Select * from turf where id = ?1",nativeQuery = true)
    Object findTrufByTurfId(Long turfId);

    @Query(value = "Select * from users where id = ?1",nativeQuery = true)
    Object findUserByUserId(Long userId);
}
