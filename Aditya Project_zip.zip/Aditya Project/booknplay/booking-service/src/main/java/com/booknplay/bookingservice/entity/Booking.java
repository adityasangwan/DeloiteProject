package com.booknplay.bookingservice.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long turfId;       // Turf being booked
    private Long userId;       // User who booked it

    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;

    private boolean confirmed;
}
