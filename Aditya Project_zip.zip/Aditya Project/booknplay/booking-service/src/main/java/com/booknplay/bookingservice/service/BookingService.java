package com.booknplay.bookingservice.service;

import com.booknplay.bookingservice.dto.BookingRequest;
import com.booknplay.bookingservice.dto.BookingResponse;
import com.booknplay.bookingservice.entity.Booking;
import com.booknplay.bookingservice.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository repo;

    public String bookSlot(BookingRequest request) {
        boolean isSlotTaken = !repo.findByTurfIdAndDateAndStartTimeLessThanAndEndTimeGreaterThan(
                request.getTurfId(), request.getDate(), request.getEndTime(), request.getStartTime()
        ).isEmpty();

        if (isSlotTaken) {
            return "Slot already booked. Please choose another.";
        }

        Booking booking = Booking.builder()
                .turfId(request.getTurfId())
                .userId(request.getUserId())
                .date(request.getDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .confirmed(true)
                .build();

        repo.save(booking);
        return "Booking confirmed!";
    }

    public List<BookingResponse> getBookings(Long userId) {
        return repo.findByUserId(userId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private BookingResponse toResponse(Booking b) {
        return new BookingResponse(
                b.getId(), b.getTurfId(), b.getUserId(), b.getDate(),
                b.getStartTime(), b.getEndTime(), b.isConfirmed()
        );
    }
}
