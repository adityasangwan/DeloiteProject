package com.booknplay.bookingservice.controller;

import com.booknplay.bookingservice.dto.BookingRequest;
import com.booknplay.bookingservice.dto.BookingResponse;
import com.booknplay.bookingservice.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    private final RestTemplate restTemplate;

    @PostMapping("/book")
    public ResponseEntity<String> bookSlot(@RequestBody BookingRequest request) {
        try {
            String message = bookingService.bookSlot(request);
            restTemplate.postForObject("http://notification-service/booking"+"?email="+request.getUserId()+"&turf="+request.getTurfId()+"&slot="+request.getDate()+" "+request.getStartTime()+" - "+request.getEndTime(),null, String.class);
            return ResponseEntity.ok(message);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingResponse>> getUserBookings(@PathVariable Long userId) {
        return ResponseEntity.ok(bookingService.getBookings(userId));
    }
}
