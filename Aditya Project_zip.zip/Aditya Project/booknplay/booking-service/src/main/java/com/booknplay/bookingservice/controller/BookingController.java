package com.booknplay.bookingservice.controller;

import com.booknplay.bookingservice.dto.BookingRequest;
import com.booknplay.bookingservice.dto.BookingResponse;
import com.booknplay.bookingservice.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping("/book")
    public ResponseEntity<String> bookSlot(@RequestBody BookingRequest request) {
        return ResponseEntity.ok(bookingService.bookSlot(request));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingResponse>> getUserBookings(@PathVariable Long userId) {
        return ResponseEntity.ok(bookingService.getBookings(userId));
    }
}
