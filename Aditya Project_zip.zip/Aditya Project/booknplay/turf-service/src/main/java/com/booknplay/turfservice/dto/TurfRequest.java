package com.booknplay.turfservice.dto;

import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class TurfRequest {
    private String name;
    private String location;
    private Long ownerId;
}
