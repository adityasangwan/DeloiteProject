package com.booknplay.turfservice.service;

import com.booknplay.turfservice.dto.TurfRequest;
import com.booknplay.turfservice.dto.TurfResponse;
import com.booknplay.turfservice.entity.Turf;
import com.booknplay.turfservice.repository.TurfRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TurfService {

    private final TurfRepository turfRepository;

    public void addTurf(TurfRequest request) {
        Object owner = turfRepository.findByOwnerIdFromTurfTable(request.getOwnerId());
        System.out.println(owner);
        if(owner == null) throw new RuntimeException("Owner not found");
        Turf turf = Turf.builder()
                .name(request.getName())
                .location(request.getLocation())
                .ownerId(request.getOwnerId())
                .approved(false)
                .build();
        turfRepository.save(turf);
    }

    public List<TurfResponse> getTurfsByOwner(Long ownerId) {
        return turfRepository.findByOwnerId(ownerId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public List<TurfResponse> getPendingTurfs() {
        return turfRepository.findByApprovedFalse().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public void approveTurf(Long turfId) {
        Turf turf = turfRepository.findById(turfId)
                .orElseThrow(() -> new RuntimeException("Turf not found"));
        turf.setApproved(true);
        turfRepository.save(turf);
    }

    private TurfResponse toResponse(Turf turf) {
        return new TurfResponse(
                turf.getId(),
                turf.getName(),
                turf.getLocation(),
                turf.getOwnerId(),
                turf.isApproved()
        );
    }
}
