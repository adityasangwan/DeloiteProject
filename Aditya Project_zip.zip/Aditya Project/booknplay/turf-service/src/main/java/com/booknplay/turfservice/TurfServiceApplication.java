package com.booknplay.turfservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurfServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(TurfServiceApplication.class, args);
    }
}

