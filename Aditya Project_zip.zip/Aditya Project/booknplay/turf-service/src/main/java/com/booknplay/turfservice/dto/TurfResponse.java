package com.booknplay.turfservice.dto;

import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class TurfResponse {
    private Long id;
    private String name;
    private String location;
    private Long ownerId;
    private boolean approved;
}
