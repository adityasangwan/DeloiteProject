package com.booknplay.turfservice.controller;

import com.booknplay.turfservice.dto.TurfRequest;
import com.booknplay.turfservice.dto.TurfResponse;
import com.booknplay.turfservice.service.TurfService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/grounds")
@RequiredArgsConstructor
public class TurfController {

    private final TurfService turfService;

    @PostMapping("/add")
    public ResponseEntity<String> addTurf(@RequestBody TurfRequest request) {
        turfService.addTurf(request);
        return ResponseEntity.ok("Turf submitted for approval");
    }

    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<TurfResponse>> getByOwner(@PathVariable Long ownerId) {
        return ResponseEntity.ok(turfService.getTurfsByOwner(ownerId));
    }

    @GetMapping("/pending")
    public ResponseEntity<List<TurfResponse>> getPending() {
        return ResponseEntity.ok(turfService.getPendingTurfs());
    }

    @PostMapping("/approve/{turfId}")
    public ResponseEntity<String> approve(@PathVariable Long turfId) {
        turfService.approveTurf(turfId);
        return ResponseEntity.ok("Turf approved successfully");
    }
}
