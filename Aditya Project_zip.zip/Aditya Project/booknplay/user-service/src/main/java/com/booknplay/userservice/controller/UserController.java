package com.booknplay.userservice.controller;

import com.booknplay.userservice.dto.*;
import com.booknplay.userservice.service.UserService;
import com.booknplay.userservice.security.JwtUtil;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/users/auth")
public class UserController {

    private final UserService userService;

    private final JwtUtil jwtUtil;

    public UserController(UserService userService, JwtUtil jwtUtil) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterRequest request) {
        userService.register(request);
        return ResponseEntity.ok("User registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(userService.login(request));
    }

    @GetMapping("/profile")
    public ResponseEntity<ProfileResponse> getProfile(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        Claims claims = jwtUtil.extractClaims(token);
        String email = claims.getSubject();
        return ResponseEntity.ok(userService.getProfile(email));
    }

    @DeleteMapping("/deleteProfile")
    public ResponseEntity<String> deleteProfile(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        Claims claims = jwtUtil.extractClaims(token);
        String email = claims.getSubject();
        userService.deleteProfile(email);
        return ResponseEntity.ok("Profile deleted successfully");
    }

    @GetMapping("/owners/pending")
    public ResponseEntity<List<ProfileResponse>> getUnapprovedOwners() {
        return ResponseEntity.ok(userService.getUnapprovedOwners());
    }

    @PostMapping("/owners/approve/{id}")
    public ResponseEntity<String> approveOwner(@PathVariable Long id) {
        userService.approveOwner(id);
        return ResponseEntity.ok("Owner approved successfully");
    }
}
