package com.booknplay.userservice.entity;

public enum Role {
    USER,
    OWNER,
    ADMIN
}
