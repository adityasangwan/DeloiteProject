package com.booknplay.userservice.service;

import com.booknplay.userservice.dto.LoginRequest;
import com.booknplay.userservice.dto.LoginResponse;
import com.booknplay.userservice.dto.ProfileResponse;
import com.booknplay.userservice.dto.RegisterRequest;
import com.booknplay.userservice.entity.Role;
import com.booknplay.userservice.entity.User;
import com.booknplay.userservice.repository.UserRepository;
import com.booknplay.userservice.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepo;
  //  private final JwtUtil jwtUtil;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final JwtUtil jwtUtil;

    public void register(RegisterRequest req) {
        Optional<User> user = userRepo.findByEmail(req.getEmail());
        if (user.isPresent()) {
            throw new RuntimeException("User already exists");
        }
        User createUser = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .role(req.getRole())
                .approved(req.getRole() != Role.OWNER)
                .build();
        userRepo.save(createUser);
    }

    public LoginResponse login(LoginRequest req) {
        User user = userRepo.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(req.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        if (user.getRole() == Role.OWNER && !user.isApproved()) {
            throw new RuntimeException("Owner is not approved yet");
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());

        return new LoginResponse(token, user.getRole().name());
    }

    public ProfileResponse getProfile(String email) {
        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return new ProfileResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name(), user.isApproved());
    }

    public List<ProfileResponse> getUnapprovedOwners() {
        return userRepo.findAll().stream()
                .filter(user -> user.getRole() == Role.OWNER && !user.isApproved())
                .map(user -> new ProfileResponse(
                        user.getId(), user.getName(), user.getEmail(),
                        user.getRole().name(), user.isApproved()))
                .collect(Collectors.toList());
    }

    public void approveOwner(Long id) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setApproved(true);
        userRepo.save(user);
    }
}
