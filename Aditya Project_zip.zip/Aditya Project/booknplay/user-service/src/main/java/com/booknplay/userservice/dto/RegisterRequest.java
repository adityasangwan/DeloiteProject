package com.booknplay.userservice.dto;

import com.booknplay.userservice.entity.Role;
import lombok.*;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private Role role;
}
